# Carrom Line Predictor (Android)

A native Android starter project for a **manual aiming and trajectory guide**. It does not connect to or modify Carrom Disc Pool; use it as a standalone practice/planning tool.

## Included
- Interactive board with draggable striker and target coin.
- Select one of four pockets.
- Direct-shot and one-cushion bank-shot display modes.
- Pocket recommendation based on approximate geometric distance.
- Separate visual lines: blue = striker-to-impact aim, green = coin route, red = estimated striker continuation, purple = bank route.
- No internet permission or data collection.

## Build an installable APK
Requirements: Android Studio (current stable), Android SDK Platform 35, JDK 17.

1. Extract this folder.
2. Open the `CarromTrajectoryPredictor` folder in Android Studio.
3. Allow Gradle sync to finish and install the requested Android SDK if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, normally:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Transfer the APK to your Android phone and allow installation from that source if Android asks.

Command-line alternative from this folder (with Gradle installed):
`gradle assembleDebug`

## Controls
- Tap **Place striker** or **Place coin**, then tap the board to reposition that object.
- Drag either object to fine-tune its location.
- Tap a pocket to select it.
- **Direct / Bank** toggles a simple bank-route visualization.
- **Recommend shot** selects a pocket using a simple geometric distance heuristic.
- **Reset** restores the initial positions.

## Accuracy and limitations
This is a buildable prototype, not a calibrated game-engine simulator. It uses idealized 2D geometry and does not model exact striker power, friction, spin, coin-to-coin collisions, moving obstacles, or the game's proprietary physics. The bank mode illustrates an approximate one-cushion path and is not guaranteed to be physically optimal. The red striker continuation is a visual estimate, not a collision-impulse solver. For a more accurate predictor, calibrate board dimensions and collision behavior from recorded shots.
