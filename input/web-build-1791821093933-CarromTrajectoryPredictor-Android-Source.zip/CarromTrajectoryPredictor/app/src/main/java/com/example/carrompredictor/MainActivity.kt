package com.example.carrompredictor

import android.app.Activity
import android.os.Bundle
import android.graphics.*
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.*

class MainActivity : Activity() {
    private lateinit var board: BoardView
    private lateinit var status: TextView
    private var placing = BoardView.Place.STRIKER

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(8))
            setBackgroundColor(Color.rgb(247, 244, 236))
        }
        val title = TextView(this).apply {
            text = "CARROM LINE PREDICTOR"
            textSize = 20f
            setTextColor(Color.rgb(44, 37, 30))
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(title)
        status = TextView(this).apply {
            text = "Select an object, then tap the board to place it."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(dp(4), dp(4), dp(4), dp(8))
        }
        root.addView(status)

        board = BoardView(this) { message -> status.text = message }
        root.addView(board, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(makeButton("Place striker") {
            placing = BoardView.Place.STRIKER
            board.setPlace(placing)
            status.text = "Tap the board to place the striker."
        }, weightParams())
        row1.addView(makeButton("Place coin") {
            placing = BoardView.Place.COIN
            board.setPlace(placing)
            status.text = "Tap the board to place the target coin."
        }, weightParams())
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(makeButton("Direct / Bank") {
            board.toggleBank()
        }, weightParams())
        row2.addView(makeButton("Recommend shot") {
            board.recommend()
        }, weightParams())
        row2.addView(makeButton("Reset") {
            board.reset()
            status.text = "Reset complete. Place the striker and target coin."
        }, weightParams())
        root.addView(row2)
        val note = TextView(this).apply {
            text = "Drag the striker/coin to fine-tune. Tap a pocket to select it. Physics are approximate."
            textSize = 11f
            setTextColor(Color.GRAY)
            setPadding(dp(3), dp(7), dp(3), 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun weightParams() = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        setMargins(dp(2), dp(3), dp(2), dp(3))
    }
    private fun makeButton(label: String, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setOnClickListener { action() }
        }
}

private data class Pt(var x: Float, var y: Float)

private class BoardView(
    context: android.content.Context,
    private val report: (String) -> Unit
) : View(context) {
    enum class Place { STRIKER, COIN }
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var board = RectF()
    private var striker = Pt(0.50f, 0.83f)
    private var coin = Pt(0.50f, 0.46f)
    private var selectedPocket = 0
    private var bankMode = false
    private var recommended = false
    private var place = Place.STRIKER
    private var dragging: Place? = null
    private var lastPlan: Plan? = null
    private val pockets = listOf(Pt(0.075f, 0.075f), Pt(0.925f, 0.075f),
        Pt(0.075f, 0.925f), Pt(0.925f, 0.925f))
    private val pocketNames = listOf("top-left", "top-right", "bottom-left", "bottom-right")

    private data class Plan(
        val aim: Pt, val coinEnd: Pt, val strikerEnd: Pt,
        val bankPoint: Pt?, val angle: Double, val distance: Double
    )

    fun setPlace(p: Place) { place = p; invalidate() }
    fun toggleBank() {
        bankMode = !bankMode
        recommended = false
        report(if (bankMode) "Bank-shot mode: showing a one-cushion route where possible."
        else "Direct-shot mode: shortest direct pocket route.")
        invalidate()
    }
    fun reset() {
        striker = Pt(0.50f, 0.83f); coin = Pt(0.50f, 0.46f)
        selectedPocket = 0; bankMode = false; recommended = false
        lastPlan = null; invalidate()
    }
    fun recommend() {
        val candidates = pockets.indices.mapNotNull { idx ->
            val old = selectedPocket
            selectedPocket = idx
            val plan = calculatePlan()
            selectedPocket = old
            plan?.let { Pair(idx, it) }
        }
        if (candidates.isNotEmpty()) {
            val best = candidates.minByOrNull { it.second.distance + if (it.second.bankPoint != null) 0.04 else 0.0 }!!
            selectedPocket = best.first
            lastPlan = best.second
            recommended = true
            report("Suggested pocket: ${pocketNames[selectedPocket]}. Aim angle: ${"%.1f".format(best.second.angle)}° from horizontal. Approximate geometry only.")
        } else {
            report("No clear shot found. Move the striker or coin and try again.")
        }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pad = 8f * density
        val side = min(width.toFloat() - 2 * pad, height.toFloat() - 2 * pad)
        val left = (width - side) / 2f
        val top = (height - side) / 2f
        board = RectF(left, top, left + side, top + side)
        canvas.drawColor(Color.rgb(247, 244, 236))
        paint.color = Color.rgb(105, 62, 32)
        canvas.drawRoundRect(RectF(board.left - 8*density, board.top - 8*density,
            board.right + 8*density, board.bottom + 8*density), 14*density, 14*density, paint)
        paint.color = Color.rgb(226, 190, 132)
        canvas.drawRect(board, paint)
        paint.color = Color.rgb(130, 76, 39)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2*density
        canvas.drawRect(board, paint); paint.style = Paint.Style.FILL
        val inset = side * 0.09f
        paint.color = Color.rgb(153, 99, 56)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1.5f*density
        canvas.drawRect(RectF(board.left+inset, board.top+inset, board.right-inset, board.bottom-inset), paint)
        paint.style = Paint.Style.FILL
        val pocketPts = pockets.map { map(it) }
        pocketPts.forEachIndexed { i, p ->
            paint.color = if (i == selectedPocket) Color.rgb(20, 20, 20) else Color.rgb(55, 42, 33)
            canvas.drawCircle(p.x, p.y, side*0.045f, paint)
            if (i == selectedPocket) {
                paint.color = Color.rgb(255, 194, 65)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f*density
                canvas.drawCircle(p.x, p.y, side*0.055f, paint); paint.style = Paint.Style.FILL
            }
        }
        drawCoin(canvas, map(coin), side*0.027f, Color.rgb(190, 38, 39), "C")
        drawCoin(canvas, map(striker), side*0.038f, Color.rgb(245, 245, 240), "S")
        val plan = if (recommended) lastPlan else calculatePlan()
        if (plan != null) drawPlan(canvas, plan, side)
        paint.color = Color.rgb(70, 53, 36)
        paint.textSize = 11*density
        canvas.drawText(if (bankMode) "BANK SHOT" else "DIRECT SHOT", board.left+8*density, board.top+18*density, paint)
        paint.textSize = 10*density
        canvas.drawText("Tap a pocket to select it", board.left+8*density, board.bottom-8*density, paint)
    }

    private fun drawCoin(canvas: Canvas, p: Pt, r: Float, color: Int, label: String) {
        paint.color = Color.argb(70, 0, 0, 0)
        canvas.drawCircle(p.x+2*density, p.y+2*density, r, paint)
        paint.color = color; canvas.drawCircle(p.x, p.y, r, paint)
        paint.color = if (label == "C") Color.WHITE else Color.DKGRAY
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = r*0.85f
        paint.typeface = Typeface.DEFAULT_BOLD
        canvas.drawText(label, p.x, p.y + r*0.3f, paint)
        paint.textAlign = Paint.Align.LEFT
    }

    private fun drawPlan(canvas: Canvas, p: Plan, side: Float) {
        val s = map(striker); val c = map(coin); val aim = map(p.aim)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f*density
        paint.color = Color.rgb(28, 95, 205)
        canvas.drawLine(s.x, s.y, aim.x, aim.y, paint)
        paint.color = Color.rgb(20, 150, 85)
        canvas.drawLine(c.x, c.y, map(p.coinEnd).x, map(p.coinEnd).y, paint)
        paint.color = Color.rgb(220, 65, 40)
        canvas.drawLine(aim.x, aim.y, map(p.strikerEnd).x, map(p.strikerEnd).y, paint)
        if (p.bankPoint != null) {
            paint.color = Color.rgb(120, 55, 180)
            val b = map(p.bankPoint)
            canvas.drawLine(c.x, c.y, b.x, b.y, paint)
            canvas.drawLine(b.x, b.y, map(p.coinEnd).x, map(p.coinEnd).y, paint)
            paint.style = Paint.Style.FILL
            canvas.drawCircle(b.x, b.y, 4*density, paint)
        }
        paint.style = Paint.Style.FILL
        paint.color = Color.rgb(28, 95, 205); canvas.drawCircle(aim.x, aim.y, 4*density, paint)
    }

    private fun calculatePlan(): Plan? {
        val c = map(coin); val pocket = map(pockets[selectedPocket]); val s = map(striker)
        val dx = pocket.x - c.x; val dy = pocket.y - c.y
        val len = hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (len < 1f) return null
        val ux = dx / len; val uy = dy / len
        val radius = board.width * 0.035f
        val aim = Pt(c.x - ux * radius * 2f, c.y - uy * radius * 2f)
        var bank: Pt? = null
        var end = pocket
        if (bankMode) {
            // Reflect the target pocket across the nearest board edge and intersect the unfolded path.
            val dl = abs(pocket.x - board.left); val dr = abs(board.right - pocket.x)
            val dt = abs(pocket.y - board.top); val db = abs(board.bottom - pocket.y)
            val minD = min(min(dl, dr), min(dt, db))
            val target = when (minD) {
                dl -> Pt(2*board.left - pocket.x, pocket.y)
                dr -> Pt(2*board.right - pocket.x, pocket.y)
                dt -> Pt(pocket.x, 2*board.top - pocket.y)
                else -> Pt(pocket.x, 2*board.bottom - pocket.y)
            }
            val bdx = target.x - c.x; val bdy = target.y - c.y
            val scale = when {
                abs(bdx) > abs(bdy) -> ((if (bdx > 0) board.right else board.left) - c.x) / bdx
                else -> ((if (bdy > 0) board.bottom else board.top) - c.y) / bdy
            }
            bank = Pt(c.x + bdx*scale, c.y + bdy*scale)
            end = pocket
        }
        val vx = c.x - s.x; val vy = c.y - s.y
        val angle = Math.toDegrees(atan2((aim.y-s.y).toDouble(), (aim.x-s.x).toDouble()))
        val strikerEnd = Pt((aim.x + vx*0.7f).coerceIn(board.left, board.right),
            (aim.y + vy*0.7f).coerceIn(board.top, board.bottom))
        return Plan(unmap(aim), unmap(end), unmap(strikerEnd), bank?.let { unmap(it) },
            angle, hypot((pocket.x-c.x).toDouble(), (pocket.y-c.y).toDouble()))
    }

    private fun map(p: Pt) = Pt(board.left + p.x*board.width, board.top + p.y*board.height)
    private fun unmap(p: Pt) = Pt(((p.x-board.left)/board.width).coerceIn(0f,1f),
        ((p.y-board.top)/board.height).coerceIn(0f,1f))

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            val s = map(striker); val c = map(coin)
            val pocketPts = pockets.map { map(it) }
            val ds = hypot((event.x-s.x).toDouble(), (event.y-s.y).toDouble())
            val dc = hypot((event.x-c.x).toDouble(), (event.y-c.y).toDouble())
            dragging = when {
                ds < board.width*0.07f -> Place.STRIKER
                dc < board.width*0.06f -> Place.COIN
                else -> null
            }
            if (dragging == null) {
                val near = pocketPts.indices.minByOrNull {
                    hypot((event.x-pocketPts[it].x).toDouble(), (event.y-pocketPts[it].y).toDouble())
                }
                if (near != null && hypot((event.x-pocketPts[near].x).toDouble(), (event.y-pocketPts[near].y).toDouble()) < board.width*0.08f) {
                    selectedPocket = near; recommended = false
                    report("Selected ${pocketNames[near]} pocket.")
                } else {
                    val normalized = unmap(Pt(event.x, event.y))
                    if (place == Place.STRIKER) striker = normalized else coin = normalized
                    recommended = false
                    report(if (place == Place.STRIKER) "Striker placed. Drag it to fine-tune." else "Target coin placed. Tap a pocket to choose a target.")
                }
            }
            invalidate(); return true
        }
        if (event.action == MotionEvent.ACTION_MOVE && dragging != null) {
            val p = unmap(Pt(event.x, event.y))
            if (dragging == Place.STRIKER) striker = p else coin = p
            recommended = false; invalidate(); return true
        }
        if (event.action == MotionEvent.ACTION_UP) {
            dragging = null
            invalidate(); return true
        }
        return true
    }
}
