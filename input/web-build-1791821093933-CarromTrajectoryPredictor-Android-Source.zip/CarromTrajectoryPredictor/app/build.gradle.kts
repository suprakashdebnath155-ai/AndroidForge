plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.carrompredictor"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.carrompredictor"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
